<?php $__env->startSection('content'); ?>
    <div class="dashboard">
        <div class="dashboard-container">
            <div class="summary-cards">
                <a href="<?php echo e(route('admin.user')); ?>" class="card">
                    <i class="fas fa-users"></i>
                    <h2>2.5K</h2>
                    <p>Users</p>
                </a>
                <a href="<?php echo e(route('admin.videos.videos')); ?>" class="card">
                    <i class="fas fa-video"></i>
                    <h2>66</h2>
                    <p>Videos</p>
                </a>
                <a href="<?php echo e(route('admin.tvshows.index')); ?>" class="card">
                    <i class="fas fa-tv"></i>
                    <h2>17</h2>
                    <p>TV Shows</p>
                </a>
                <a href="<?php echo e(route('admin.banner.home')); ?>" class="card">
                    <i class="fas fa-broadcast-tower"></i>
                    <h2>27</h2>
                    <p>Channel</p>
                </a>
                <a href="<?php echo e(route('admin.cast')); ?>" class="card">
                    <i class="fas fa-user-friends"></i>
                    <h2>250</h2>
                    <p>Cast</p>
                </a>
            </div>

            <div class="earnings-cards">
                <a href="#" class="card">
                    <i class="fas fa-dollar-sign"></i>
                    <h2>$5.8K</h2>
                    <p>Monthly Package Earnings</p>
                </a>
                <a href="#" class="card">
                    <i class="fas fa-box"></i>
                    <h2>$3</h2>
                    <p>Package</p>
                </a>
                <a href="#" class="card">
                    <i class="fas fa-money-bill"></i>
                    <h2>$0</h2>
                    <p>Monthly Rent Earnings</p>
                </a>
                <a href="#" class="card">
                    <i class="fas fa-chart-line"></i>
                    <h2>$316</h2>
                    <p>Rent Earnings</p>
                </a>
            </div>

            <div class="most-viewed">
                <h3>Most Viewed Video & TV Show</h3>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Video / TV Show</th>
                            <th>Views</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1.</td>
                            <td>Anek</td>
                            <td><i class="fas fa-eye"></i> 156.5K</td>
                        </tr>
                        <tr>
                            <td>2.</td>
                            <td>Attack: Part 1</td>
                            <td><i class="fas fa-eye"></i> 22.6K</td>
                        </tr>
                        <tr>
                            <td>3.</td>
                            <td>Ek Villain Returns</td>
                            <td><i class="fas fa-eye"></i> 16.5K</td>
                        </tr>
                        <tr>
                            <td>4.</td>
                            <td>Sooryavanshi</td>
                            <td><i class="fas fa-eye"></i> 9.8K</td>
                        </tr>
                        <tr>
                            <td>5.</td>
                            <td>Daag: The Fire</td>
                            <td><i class="fas fa-eye"></i> 9.6K</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\Movie_Admin\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>