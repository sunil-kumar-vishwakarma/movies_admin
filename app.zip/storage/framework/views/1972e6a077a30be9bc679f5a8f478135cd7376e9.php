<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="search-sort">
            <div class="search-container">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" placeholder="Search Videos...">
            </div>
            <div class="sort-container">
                <select class="sort-select" id="sort-select">
                    <option value="all">All Type</option>
                    <option value="Today">Comedy</option>
                    <option value="Month">Horror</option>
                    <option value="Year">Sports</option>
                </select>
            </div>
            <div class="sort-container">
                <select class="sort-select" id="sort-select">
                    <option value="all">All Type</option>
                    <option value="Today">Rent Video</option>
                </select>
            </div>
        </div>

        <main class="main-content">
            <section class="videos-list">
                <div class="videos-container">
                    <div class="video-card add-video-card">
                        <button class="add-video-btn">
                            <span class="add-icon"><i class="fas fa-plus"></i></span>
                            <span class="add-text">Add New</span>
                        </button>
                    </div>

                    <!-- Import Form -->
                    <form class="import-form" action="import_from_tm_db" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="video-item">
                            <div class="video-image">
                                <div class="video-card-overlay">
                                    <button class="play-btn"><i class="fas fa-play"></i></button>
                                    <div class="video-card-icons">
                                        <button class="like-btn"><i class="fas fa-chart-line"></i></button>
                                        <button class="edit-btn"><i class="fas fa-edit"></i></button>
                                        <button class="delete-btn"><i class="fas fa-trash"></i></button>
                                    </div>
                                </div>
                                <img src="https://via.placeholder.com/400x225" alt="Thumbnail" class="video-thumbnail">
                            </div>
                            <div class="video-details">
                                <label for="tmdb-id">Enter TMDb ID (e.g. 214)</label>
                                <input type="text" id="tmdb-id" name="tmdb_id" class="form-control">

                                <label for="movie-name">Movies Name</label>
                                <input type="text" id="movie-name" name="name" class="form-control">

                                <label for="type">Type</label>
                                <select id="type" name="type" class="form-select">
                                    <option value="">Select Type</option>
                                    <option value="Comedy">Comedy</option>
                                    <option value="Action">Action</option>
                                    <!-- Add more options as needed -->
                                </select>

                                <label for="ads-video-duration">Ads Video duration</label>
                                <input type="text" id="ads-video-duration" name="ads_video_duration" class="form-control">

                                <label for="category">Category</label>
                                <select id="category" name="category" class="form-select">
                                    <option value="">Select Category</option>
                                    <option value="Bollywood">Bollywood</option>
                                    <!-- Add more options as needed -->
                                </select>

                                <label for="language">Language</label>
                                <select id="language" name="language" class="form-select">
                                    <option value="">Select Language</option>
                                    <option value="English">English</option>
                                    <!-- Add more options as needed -->
                                </select>

                                <label for="cast">Cast</label>
                                <textarea id="cast" name="cast" class="form-control"></textarea>

                                <label for="video-duration">Video Duration</label>
                                <input type="text" id="video-duration" name="duration" class="form-control">

                                <label for="release-date">Release Date</label>
                                <input type="date" id="release-date" name="release_date" class="form-control">

                                <label for="producer">Producer</label>
                                <select id="producer" name="producer" class="form-select">
                                    <option value="">Select Producer</option>
                                    <!-- Add producer options -->
                                </select>

                                <label for="video-upload-type">Video Upload Type</label>
                                <select id="video-upload-type" name="video_upload_type" class="form-select">
                                    <option value="Server Video">Server Video</option>
                                    <!-- Add more options as needed -->
                                </select>

                                <label for="is-premium">Is Premium</label>
                                <select id="is-premium" name="is_premium" class="form-select">
                                    <option value="No">No</option>
                                    <option value="Yes">Yes</option>
                                </select>

                                <label for="is-title">Is Title</label>
                                <select id="is-title" name="is_title" class="form-select">
                                    <option value="No">No</option>
                                    <option value="Yes">Yes</option>
                                </select>

                                <label for="is-download">Is Download</label>
                                <select id="is-download" name="is_downloadable" class="form-select">
                                    <option value="No">No</option>
                                    <option value="Yes">Yes</option>
                                </select>

                                <label for="upload-video-320px">Upload Video (320 px)</label>
                                <input type="file" id="upload-video-320px" name="video_320px" class="form-control">

                                <label for="upload-video-480-px">Upload Video (480 px)</label>
                                <input type="file" id="upload-video-480-px" name="video_480px" class="form-control">

                                <label for="upload-video-720-px">Upload Video (720 px)</label>
                                <input type="file" id="upload-video-720-px" name="video_720px" class="form-control">

                                <label for="upload-video-1080-px">Upload Video (1080 px)</label>
                                <input type="file" id="upload-video-1080-px" name="video_1080px" class="form-control">

                                <label for="trailer-type">Trailer Type</label>
                                <select id="trailer-type" name="trailer_type" class="form-select">
                                    <option value="Server Video">Server Video</option>
                                    <!-- Add more options as needed -->
                                </select>

                                <label for="trailer">Trailer</label>
                                <input type="file" id="trailer" name="trailer" class="form-control">

                                <label for="subtitle-type">Subtitle Type</label>
                                <select id="subtitle-type" name="subtitle_type" class="form-select">
                                    <option value="Server Video">Server Video</option>
                                    <!-- Add more options as needed -->
                                </select>

                                <label for="language-name">Language Name</label>
                                <input type="text" id="language-name" name="language_name" class="form-control">

                                <label for="upload-subtitle">Upload Subtitle</label>
                                <input type="file" id="upload-subtitle" name="subtitle" class="form-control">

                                <label for="description">Description</label>
                                <textarea id="description" name="description" class="form-control"></textarea>

                                <label for="is-rent">Is Rent</label>
                                <select id="is-rent" name="is_rent" class="form-select">
                                    <option value="No">No</option>
                                    <option value="Yes">Yes</option>
                                </select>

                                <label for="is-comment">Is Comment</label>
                                <select id="is-comment" name="is_comment" class="form-select">
                                    <option value="No">No</option>
                                    <option value="Yes">Yes</option>
                                </select>

                                <label for="is-like">Is Like</label>
                                <select id="is-like" name="is_like" class="form-select">
                                    <option value="No">No</option>
                                    <option value="Yes">Yes</option>
                                </select>

                                <label for="thumbnail-image">Thumbnail Image</label>
                                <input type="file" id="thumbnail-image" name="thumbnail_image" class="form-control">

                                <label for="landscape-image">Landscape Image</label>
                                <input type="file" id="landscape-image" name="landscape_image" class="form-control">

                                <button type="submit" class="form-submit">Import</button>
                            </div>
                        </form>
                        <!-- End of Import Form -->
                    </div>
                </div>
            </section>
        </main>
    </div>

    <style>
        .videos-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .videos-list {
            width: 100%;
        }

        .video-card {
            position: relative;
            overflow: hidden;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: transform 0.3s ease;
            background-color: #fff;
            height: 250px; /* Adjusted height */
        }

        .video-card:hover {
            transform: scale(1.05);
        }

        .video-image {
            position: relative;
            overflow: hidden;
            width: 100%;
            height: 180px; /* Adjusted height */
        }

        .video-card-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .video-card:hover .video-card-overlay {
            opacity: 1;
        }

        .play-btn,
        .like-btn,
        .edit-btn,
        .delete-btn {
            background: none;
            border: none;
            color: white;
            font-size:24px;
            cursor: pointer;
        }

        .video-card-icons {
            position: absolute;
            bottom: 10px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .add-video-card {
            display: flex;
            justify-content: center;
            align-items: center;
            background: #f0f0f0;
            flex: 1;
            cursor: pointer;
        }

        .add-video-btn {
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .add-video-btn .add-icon {
            border: 2px solid white;
            border-radius: 50%;
            padding: 5px;
        }

        .add-video-btn:hover {
            background: #0056b3;
        }

        .video-thumbnail {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 5px;
        }

        .video-info {
            padding: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background: #f9f9f9f9;
            border-top: 1px solid #ccc;
        }

        .video-title {
            font-weight: bold;
            margin: 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .toggle-btn {
            margin-top: 5px;
            padding: 5px 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .toggle-btn:hover {
            background: #0056b3;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\Movie_Admin\resources\views/admin/videos.blade.php ENDPATH**/ ?>