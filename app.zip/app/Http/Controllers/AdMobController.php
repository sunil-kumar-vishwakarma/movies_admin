<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdMobController extends Controller
{
    public function admob()
    {
        return view('admin.admob');
    }

}
